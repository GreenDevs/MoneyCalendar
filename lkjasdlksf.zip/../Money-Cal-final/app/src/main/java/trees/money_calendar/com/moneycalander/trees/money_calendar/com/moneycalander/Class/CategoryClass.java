package trees.money_calendar.com.moneycalander.trees.money_calendar.com.moneycalander.Class;

/**
 * Created by trees on 6/26/15.
 */
public class CategoryClass {

    //CATEGORIES WE HAVE///
    public static final String MISCAL = "Miscellaneous";
    public static final String GROC = "Grocery";
    public static final String FOOD = "Fooding";
    public static final String SHOP = "Shopping";
    public static final String EDU = "Education";
    public static final String PERSO = "Personal";
    public static final String MAINT = "Maintainance";
    public static final String ENTERT = "Entertaintment";
    public static final String HEALTH = "Health";
    public static final String TRAVEL = "Travel";
    public static final String SAVE = "Saving";
    public static final String HOME = "Home";


    //MONTHS

    public static final String MONTHS[] = {"jan", "feb", "mar", "apr", "may", "jun","jul", "aug", "sep", "oct", "nov", "dec"};


}
