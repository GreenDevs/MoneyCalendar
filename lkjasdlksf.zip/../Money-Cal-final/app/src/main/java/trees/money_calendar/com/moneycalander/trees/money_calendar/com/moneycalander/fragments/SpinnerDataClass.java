package trees.money_calendar.com.moneycalander.trees.money_calendar.com.moneycalander.fragments;

/**
 * Created by trees on 6/8/15.
 */
public class SpinnerDataClass
{

        int images;
        String categories;

        SpinnerDataClass(int images, String categories)
        {
            this.images=images;
            this.categories=categories;
        }
}
